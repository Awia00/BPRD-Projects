void main(int n) {
  int length;
  int hello[5];
  int i;
  length = 5;
  hello[0] = 1;
  hello[1] = 2;
  hello[2] = 3;
  hello[3] = 4;
  hello[4] = 5;
  i = 0;
  while(i < 5) {
    print hello[i];
    i = i+1;
  }
  println;
}