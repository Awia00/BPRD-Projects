void main(int n) {
  int *a;
  *a = 5;
  print a;
  print *a;
}