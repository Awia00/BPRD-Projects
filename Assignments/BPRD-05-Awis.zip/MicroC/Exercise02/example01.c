void main(int n) {
  print(n + n);
  println;
}