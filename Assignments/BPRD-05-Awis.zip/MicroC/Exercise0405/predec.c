void main(int n) {
  int i;
  i = 1;
  print i;
  println;
  --i;
  print i;
  println;
  --i;
  print i;
  println;
}