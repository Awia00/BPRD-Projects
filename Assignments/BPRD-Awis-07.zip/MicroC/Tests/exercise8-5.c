// test ExprIf
void main() {
	int i;
	i = true ? 1 : 2;
	print i; // print 1;
	i = false ? 1 : 2;
	print i; // print 2;
}