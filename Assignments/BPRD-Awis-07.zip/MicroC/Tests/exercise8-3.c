// test preinc and predec
void main() {
	int result;
	int i;
	i = 2;
	result = ++i * 2; // 6
	print result;
	int j;
	j = 3;
	result = --j * 2; // 4
	print result;
}