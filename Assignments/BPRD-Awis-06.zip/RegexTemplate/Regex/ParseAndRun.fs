﻿module ParseAndRun

let fromString s = Parse.fromString s;;